(function () {
    'use strict';

    angular.module('myApp', ["ngRoute"])

        .controller('MyController', function ($scope, $http) {
            $http.get('http://localhost:3000/get').then(function (response) {
                $scope.datas = response.data
            })
        })



        .config(function ($routeProvider) {
            $routeProvider
                .when("/", {
                    templateUrl: "Display.html"
                })
        })
        .config(['$locationProvider', function ($locationProvider) {
            $locationProvider.hashPrefix('');
        }])
})();